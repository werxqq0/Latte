from com.werxqq0.lattecmd.latte.libs.__builtins__ import *
from com.werxqq0.lattecmd.latte.libs.__xml__ import *
from com.werxqq0.lattecmd.latte.project.economy.base import *

def chat():
    global balance
    prefix = 'Server: '
    prefixp = 'Player: '

    while On:
        chat_input = console.put()

        if chat_input == cmd('balance'):
            console.out(prefix + f'Your balance is {balance}$')
        elif chat_input == cmd('give'):
            console.out(prefix + 'Invalid use of command. Please use "/give <amount>" format.')
        elif chat_input.startswith('/give '):
            try:
                amount = int(chat_input.split(' ')[1])
                balance += amount
                console.out(prefix + f'{amount}$ have been added to your balance.')
            except ValueError:
                console.out(prefix + 'Invalid amount. Please use "/give <amount>" format.')
        elif chat_input == cmd('take'):
            console.out(prefix + 'Invalid use of command. Please use "/take <amount>" format.')
        elif chat_input.startswith('/take '):
            try:
                amount = int(chat_input.split(' ')[1])
                balance -= amount
                console.out(prefix + f'{amount}$ have been taked from your balance.')
            except ValueError:
                console.out(prefix + 'Invalid amount. Please use "/take <amount>" format.')
        elif chat_input.startswith('/'):
            console.out('This command does not exist.')
        else:
            console.out(prefixp + chat_input)