# Latte 1.0.0

class Console:
    def out(self, *args):
        return print(*args)
    def put(self, *args):
        return input(*args)

console = Console()

On = True
Off = False