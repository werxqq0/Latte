from com.werxqq0.lattecmd.latte.libs.__builtins__ import *
from com.werxqq0.lattecmd.latte.libs.__xml__ import *

def chat():
    prefix = 'Server: '
    prefixp = 'Player: '

    while On:
        chat_input = console.put()

        if chat_input == cmd('hellocmd'):
            console.out(prefix + 'Hello!')
        elif chat_input == cmd('example'):
            console.out(prefix + 'Just an example.')
        elif chat_input.startswith('/'):
            console.out('This command does not exist.')
        else:
            console.out(prefixp + chat_input)