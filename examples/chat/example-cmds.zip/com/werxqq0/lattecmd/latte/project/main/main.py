from com.werxqq0.lattecmd.latte.libs.__builtins__ import *
from com.werxqq0.lattecmd.latte.project.cmd.base import *

chat()