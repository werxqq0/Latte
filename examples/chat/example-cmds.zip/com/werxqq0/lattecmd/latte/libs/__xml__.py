import xml.etree.ElementTree as xml
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
project_dir = current_dir
for _ in range(5):
    project_dir = os.path.dirname(project_dir)
xml_path = os.path.join(project_dir, "project.xml")

tree = xml.parse(xml_path)
root = tree.getroot()

cmds_element = root.find('./cmds')

variables = {}
for variable_element in cmds_element:
    variable_name = variable_element.tag
    variable_value = variable_element.text
    variables[variable_name] = variable_value

def cmd(cmd_name):
    return f'{variables[cmd_name]}'